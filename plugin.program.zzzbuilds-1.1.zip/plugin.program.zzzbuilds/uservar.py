import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://zzzbuilds.com/kodi/files/builds/buildfile.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://zzzbuilds.com/kodi/files/builds/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever.']
